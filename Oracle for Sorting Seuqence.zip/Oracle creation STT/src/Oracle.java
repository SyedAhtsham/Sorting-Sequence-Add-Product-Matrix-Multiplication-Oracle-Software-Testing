import java.net.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.io.BufferedReader;
import java.io.File; // Import the File class
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException; // Import the IOException class to handle errors
import java.io.InputStream;
import java.io.Writer;

public class Oracle {

	public static List<ArrayList<Integer>> bigList = new ArrayList<ArrayList<Integer>>();;
	public static List<ArrayList<Integer>> sortedBigList = new ArrayList<ArrayList<Integer>>();;

	static void swap(Integer[] arr, int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}

	static int partition(Integer[] arr, int low, int high, int requestInt) {

		// pivot
		int pivot = arr[high];

		// Index of smaller element and
		// indicates the right position
		// of pivot found so far
		int i = (low - 1);

		for (int j = low; j <= high - 1; j++) {

			// If current element is smaller
			// than the pivot

			if (requestInt == 1) {

				if (arr[j] < pivot) {

					// Increment index of
					// smaller element
					i++;
					swap(arr, i, j);
				}
			} else {
				if (arr[j] > pivot) {

					// Increment index of
					// smaller element
					i++;
					swap(arr, i, j);
				}
			}
		}
		swap(arr, i + 1, high);
		return (i + 1);
	}

	static void quickSort(Integer[] arr, int low, int high, int requestInt) {
		if (low < high) {

			// pi is partitioning index, arr[p]
			// is now at right place
			int pi = partition(arr, low, high, requestInt);

			// Separately sort elements before
			// partition and after partition
			quickSort(arr, low, pi - 1, requestInt);
			quickSort(arr, pi + 1, high, requestInt);
		}
	}

	public static void printSequence(List<Integer> myList, char requestedChar) {
		System.out.println();
		System.out.print("Your Input Sequence: ");

		for (int i = 0; i < myList.size(); i++) {
			System.out.print(myList.get(i) + ", ");
		}
		System.out.println(requestedChar);
		System.out.println();

	}

	public static void writeToFile(List<Integer> numbersList, char requestedChar, FileWriter inputFileWriter)
			throws IOException {

		inputFileWriter.write("\n");
		for (Integer num : numbersList) {
			inputFileWriter.write(num.toString() + ",");

		}
		inputFileWriter.write(requestedChar);

	}

	public static ArrayList<Integer> convertToIntegerList(String[] strArr) {
		int i = 0;
		ArrayList<Integer> list = new ArrayList<Integer>();
		for (; i < strArr.length - 1; i++) {

			list.add(Integer.parseInt(strArr[i]));
		}

		if (strArr[i].equals("A")) {
			list.add(1); // for A we used 1 at the end of the sequence
		} else {
			list.add(0); // for D we used 0 at the end of the sequence
		}
		return list;
	}

	public static void readFile(String fileName) throws IOException {

		File file = new File("input_file.txt");
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String str;
		str = br.readLine();
		while ((str = br.readLine()) != null) {

			bigList.add(convertToIntegerList(str.split(",")));

		}

		br.close();

	}

	public static void addToSortedSequence(Integer[] arr) {
		ArrayList<Integer> list = new ArrayList<Integer>(arr.length);
		for (int i = 0; i < arr.length; i++) {
			list.add(arr[i]);

		}

		sortedBigList.add(list);
	}

	public static void sortSequences() {

		for (int i = 0; i < bigList.size(); i++) {
			Integer[] array = bigList.get(i).toArray(new Integer[0]);
			quickSort(array, 0, array.length - 2, array[array.length - 1]);
			addToSortedSequence(array);
		}

	}

	public static void printSortedSequences() {

		for (int i = 0; i < sortedBigList.size(); i++) {
			System.out.println(sortedBigList.get(i) + "\n");
		}
	}

	public static void writeObservedOutputToFile(String fileName) throws IOException {
		FileWriter outputWriter = new FileWriter(fileName);
		outputWriter.write("Observed Sorted Output\n");
		int j;
		for (int i = 0; i < sortedBigList.size(); i++) {
			for ( j = 0; j < sortedBigList.get(i).size() - 1; j++) {
				outputWriter.write(sortedBigList.get(i).get(j).toString() + ",");
			}
			if (sortedBigList.get(i).get(j) == 1) {
				outputWriter.write('A');
			}else {
				outputWriter.write('D');
			}
			outputWriter.write("\n");
		}
		outputWriter.close();

	}
	
	
	//Oracle routine to give the verdict for test cases
	
	public static void Oracle(String observedOutputFile, String expectedOutputFile) throws IOException {
		
		
		
		
		String verdict = "";
		File observedFileReader = new File(observedOutputFile);
		File expectedFileReader = new File(expectedOutputFile);
		
		BufferedReader brO = null;
		BufferedReader brE = null;
		try {
			brO = new BufferedReader(new FileReader(observedFileReader));
			brE = new BufferedReader(new FileReader(expectedFileReader));
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		FileWriter outputWriter = new FileWriter("test_logFile.txt");
		outputWriter.write("  Test Case No.\t\tExpected Output\t\tObservedOutput\t\tVerdict\n");

		
		String strO,strE;
		strO = brO.readLine();
		strE = brE.readLine();
		
		int count = 1;
		while (((strO = brO.readLine()) != null) && ((strE = brE.readLine()) != null)) {

			if(strO.equals(strE)) {
				verdict = "Pass";
			}
			else {
				verdict = "Fail";
			}
		
			outputWriter.write("\t"+count+"\t\t" + strE +"\t\t" + strO + "\t\t"+ verdict+"\n");

			count++;
			
		}

		brE.close();
		brO.close();

		outputWriter.close();		
	}
	
	
	
	public static void main(String[] args) throws IOException {

		// TODO Auto-generated method stub

		FileWriter inputFileWriter = new FileWriter("input_file.txt", true);

		inputFileWriter.write("Input Sequences" + "\n");

		List<Integer> numbersList = new ArrayList<Integer>();
		String str = new String();
		Scanner sc = new Scanner(System.in);
		int num = 0;
		char requestedChar = ' ';
		char ch = ' ';

		try {
		      File inputFileObj = new File("input_file.txt");
		      if (inputFileObj.createNewFile()) {
		        System.out.println("File created: " + inputFileObj.getName());
		      } else {
		        //System.out.println("File already exists.");
		      }
		    } catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		

		// INPUT numbers from user and a request character A or D
//
		do {

			System.out.println("Please enter a sequence of numbers to be sorted preceded by a request  ");
			System.out.println("character 'A' (for Ascending) or 'D' (for Descending) : ");

			do {

				str = sc.nextLine();
				if (str.equals("A") || str.equals("a") || str.equals("d") || str.equals("D")) {

					requestedChar = Character.toUpperCase(str.charAt(0));

					break;

				} else {
					try {
						num = Integer.parseInt(str);
						numbersList.add(num);

					} catch (Exception e) {
						// TODO: handle exception
						System.out.println("Please enter a valid integer number or request character!");
					}

				}

			} while (true);

			printSequence(numbersList, requestedChar);

			writeToFile(numbersList, requestedChar, inputFileWriter);

			numbersList.clear();
			requestedChar = ' ';

			System.out.println("Do you want to add more input sequence to the file? 'y' (YES) or 'n' (NO) : ");
			ch = sc.next().charAt(0);
			sc.nextLine();

			System.out.println();
		} while (ch == 'y' || ch == 'Y');

		inputFileWriter.close();

		// Read input file and write the sorted sequences into another file i.e.,
		// observed output file

		readFile("input_file.txt");
		sortSequences();
		printSortedSequences();
		writeObservedOutputToFile("observed_output.txt");
	
		Oracle("observed_output.txt", "expected_output.txt");
	
	}

}

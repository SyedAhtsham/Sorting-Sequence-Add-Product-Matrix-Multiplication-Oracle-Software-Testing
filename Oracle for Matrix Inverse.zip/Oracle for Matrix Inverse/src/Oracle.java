import java.text.DecimalFormat;
import java.util.*;

public class Oracle {

	public static boolean OracleFun(double[][] InverseMatrix, double[][] orignalMatrix, int rows, int cols) {

		double product[][] = new double[2][2];
		double identityMatrix[][] = {{1,0},{0,1}};

		for (int i = 0; i < rows; i++) {

			for (int j = 0; j < cols; j++) {
				product[i][j] = 0;
				for (int k = 0; k < cols; k++) {
					product[i][j] += InverseMatrix[i][k] * orignalMatrix[k][j];
				} // end of k loop
				
				DecimalFormat df = new DecimalFormat("#.##");
				
				if((Math.round(product[i][j])) != Math.round(identityMatrix[i][j])){
					return false;
				}
			}
			
			
		}
		
		return true;

		
	}

	public static void main(String[] args) {

		double determinant;
		double inverseMatrix[][] = new double[2][2];
		double temp_var = 0;
		double myMatrix[][] = new double[2][2]; // 2x2 matrix fixed size
		double orignalMatrix[][] = new double[2][2];
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter elements of 2x2 matrix:");

		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 2; j++) {
				myMatrix[i][j] = sc.nextDouble();
				orignalMatrix[i][j] = myMatrix[i][j];
				
			}
		}

		determinant = (myMatrix[0][0] * myMatrix[1][1]) - (myMatrix[0][1] * myMatrix[1][0]);
		System.out.println("\ndeterminant = " + determinant);

		temp_var = myMatrix[0][0];
		myMatrix[0][0] = myMatrix[1][1];
		myMatrix[1][1] = temp_var;
		myMatrix[0][1] = -myMatrix[0][1];
		myMatrix[1][0] = -myMatrix[1][0];

		System.out.println("\nInverse of matrix is:");
		System.out.println();
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 2; j++) {
				
				inverseMatrix[i][j] = myMatrix[i][j] / determinant;
				System.out.print(inverseMatrix[i][j]+" ");
			}
			System.out.print("\n");

		}
		
		System.out.println();
		if( OracleFun(inverseMatrix, orignalMatrix, 2, 2)) {
			System.out.println("Verdict: Pass! ");
		}
		else {
			System.out.println("Verdict: Fail! ");
		}
	}
}